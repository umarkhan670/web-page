$(document).ready(function () {
    $('.slick-carousel').slick({
        dots: true,
        slidesToShow: 2,
        centerMode: true,
        variableWidth: true,
        autoplay: true,
        autoplaySpeed: 1000,
    });
});